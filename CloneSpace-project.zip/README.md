# Clone Space (spike build)

APK বানানোর ধাপ (Android Studio ছাড়াই):
1. github.com এ নতুন একটা repository খুলুন।
2. এই ফোল্ডারের সব ফাইল (লুকানো `.github` ফোল্ডারসহ) আপলোড করুন, branch নাম `main`।
3. Actions ট্যাব → "Build APK" → Run workflow। প্রায় ৫–১০ মিনিট লাগে।
4. শেষ হলে সেই run এর নিচে Artifacts থেকে `app-debug-apk` নামিয়ে unzip করুন, `app-debug.apk` ফোনে ইনস্টল করুন।
5. build ব্যর্থ হলে Actions এর লগের শেষ ৪০ লাইন আমাকে পাঠান।

এটা spike: ক্লোন প্রোফাইল তৈরি, অ্যাপ ক্লোন, চালু, মোছা। Android ৯ বা তার উপরে।
