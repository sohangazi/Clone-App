package com.example.clonespace

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build

class Db(c: Context) : SQLiteOpenHelper(c, "clones.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("""create table cloned_apps (
            id integer primary key autoincrement,
            source_package text not null,
            clone_index integer not null default 1 check (clone_index >= 1),
            display_name text not null,
            custom_icon_uri text,
            status text not null default 'ready' check (status in ('creating','ready','failed','removing')),
            created_at integer not null,
            updated_at integer not null,
            last_opened_at integer,
            unique (source_package, clone_index))""")
        d.execSQL("""create table launch_log (
            id integer primary key autoincrement,
            cloned_app_id integer not null references cloned_apps(id) on delete cascade,
            launched_at integer not null,
            result text not null check (result in ('ok','crashed','closed_early','blocked')),
            android_sdk integer not null,
            detail text)""")
        d.execSQL("create table settings (key text primary key, value text not null, updated_at integer not null)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun list(): List<Pair<String, String>> =
        readableDatabase.rawQuery(
            "select source_package, display_name from cloned_apps order by display_name", null
        ).use { c -> buildList { while (c.moveToNext()) add(c.getString(0) to c.getString(1)) } }

    fun add(pkg: String, name: String) {
        val now = System.currentTimeMillis()
        val v = ContentValues().apply {
            put("source_package", pkg); put("display_name", name)
            put("created_at", now); put("updated_at", now)
        }
        writableDatabase.insertWithOnConflict("cloned_apps", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun remove(pkg: String) {
        writableDatabase.delete("cloned_apps", "source_package=?", arrayOf(pkg))
    }

    fun log(pkg: String, result: String) {
        writableDatabase.execSQL(
            "insert into launch_log(cloned_app_id, launched_at, result, android_sdk) " +
                "select id, ?, ?, ? from cloned_apps where source_package=?",
            arrayOf<Any>(System.currentTimeMillis(), result, Build.VERSION.SDK_INT, pkg)
        )
    }
}
