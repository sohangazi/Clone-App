package com.example.clonespace

import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.UserManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap

class MainActivity : ComponentActivity() {
    private lateinit var db: Db
    private val tick = mutableIntStateOf(0)
    private var pendingPkg: String? = null
    private var pendingAction: String? = null

    private val provision = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        tick.intValue++
    }

    private val op = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val pkg = pendingPkg
        if (pkg != null) {
            val ok = r.resultCode == RESULT_OK
            when (pendingAction) {
                ProfileOpsActivity.ACTION_CLONE -> if (ok) db.add(pkg, label(pkg))
                ProfileOpsActivity.ACTION_REMOVE -> if (ok) db.remove(pkg)
                ProfileOpsActivity.ACTION_LAUNCH -> db.log(pkg, if (ok) "ok" else "blocked")
            }
            if (!ok) toast(getString(R.string.failed))
        }
        tick.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        setContent { CloneTheme { App() } }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(pkg: String): String =
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()

    private fun profileReady(): Boolean =
        getSystemService(UserManager::class.java).userProfiles.size > 1

    private fun startProvision() {
        val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).putExtra(
            DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
            ComponentName(this, AdminReceiver::class.java))
        try { provision.launch(i) } catch (e: ActivityNotFoundException) { toast(getString(R.string.failed)) }
    }

    private fun runOp(action: String, pkg: String) {
        pendingAction = action
        pendingPkg = pkg
        try {
            op.launch(Intent(action).putExtra(ProfileOpsActivity.EXTRA_PKG, pkg))
        } catch (e: ActivityNotFoundException) { toast(getString(R.string.failed)) }
    }

    private fun installedApps(): List<Pair<String, String>> {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
            .map { it to label(it) }
            .sortedBy { it.second.lowercase() }
    }

    @Composable
    private fun App() {
        var picking by remember { mutableStateOf(false) }
        val t = tick.intValue
        val ready = remember(t) { profileReady() }
        val clones = remember(t) { db.list() }
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.padding(16.dp)) {
                if (picking) Picker { picking = false }
                else Home(ready, clones) { picking = true }
            }
        }
    }

    @Composable
    private fun Home(ready: Boolean, clones: List<Pair<String, String>>, onAdd: () -> Unit) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(if (ready) R.string.profile_ready else R.string.profile_missing))
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { if (ready) onAdd() else startProvision() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
        ) { Text(stringResource(if (ready) R.string.add_app else R.string.create_profile)) }
        Spacer(Modifier.height(12.dp))
        if (clones.isEmpty()) Text(stringResource(R.string.clones_empty))
        LazyColumn {
            items(clones) { (pkg, name) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(pkg)
                    Text(name, Modifier.weight(1f).padding(horizontal = 12.dp))
                    Button(onClick = { runOp(ProfileOpsActivity.ACTION_LAUNCH, pkg) }) {
                        Text(stringResource(R.string.launch))
                    }
                    TextButton(onClick = { runOp(ProfileOpsActivity.ACTION_REMOVE, pkg) }) {
                        Text(stringResource(R.string.remove))
                    }
                }
            }
        }
    }

    @Composable
    private fun Picker(onBack: () -> Unit) {
        val apps = remember { installedApps() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.pick_title), style = MaterialTheme.typography.titleMedium)
        }
        LazyColumn {
            items(apps) { (pkg, name) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(pkg)
                    Text(name, Modifier.weight(1f).padding(horizontal = 12.dp))
                    Button(onClick = { runOp(ProfileOpsActivity.ACTION_CLONE, pkg); onBack() }) {
                        Text(stringResource(R.string.clone))
                    }
                }
            }
        }
    }

    @Composable
    private fun AppIcon(pkg: String) {
        val bmp = remember(pkg) {
            runCatching { packageManager.getApplicationIcon(pkg).toBitmap(112, 112).asImageBitmap() }.getOrNull()
        }
        if (bmp != null) Image(bmp, contentDescription = null, modifier = Modifier.size(56.dp))
    }
}
