package com.example.clonespace

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle

/** Runs inside the clone profile (reached through the cross-profile intent filter). */
class ProfileOpsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG)
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, AdminReceiver::class.java)
        var ok = false
        if (pkg != null && dpm.isProfileOwnerApp(packageName)) {
            try {
                when (intent.action) {
                    ACTION_CLONE -> ok = dpm.installExistingPackage(admin, pkg)
                    ACTION_LAUNCH -> {
                        val i = packageManager.getLaunchIntentForPackage(pkg)
                        if (i != null) { startActivity(i); ok = true }
                    }
                    ACTION_REMOVE -> {
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                        ok = true
                    }
                }
            } catch (e: Exception) { ok = false }
        }
        setResult(if (ok) RESULT_OK else RESULT_CANCELED)
        finish()
    }

    companion object {
        const val ACTION_CLONE = "com.example.clonespace.CLONE"
        const val ACTION_LAUNCH = "com.example.clonespace.LAUNCH"
        const val ACTION_REMOVE = "com.example.clonespace.REMOVE"
        const val EXTRA_PKG = "pkg"
    }
}

/** Android 12+: tells the system we want a work profile. */
class ProvisioningModeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31) {
            setResult(RESULT_OK, Intent().putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_MODE,
                DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE))
        }
        finish()
    }
}

/** Required by the provisioning flow on newer Android. */
class ComplianceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_OK)
        finish()
    }
}
