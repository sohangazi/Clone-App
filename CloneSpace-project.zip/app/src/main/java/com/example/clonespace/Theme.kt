package com.example.clonespace

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    background = Color(0xFFFFFFFF),
    surface = Color(0xFFF6F7F9),
    outline = Color(0xFF868E98),
    outlineVariant = Color(0xFFE3E6EA),
    onBackground = Color(0xFF14171C),
    onSurface = Color(0xFF14171C),
    onSurfaceVariant = Color(0xFF5B6470),
    primary = Color(0xFF2F5BEA),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE8EEFF),
    onPrimaryContainer = Color(0xFF1B3AA6),
    error = Color(0xFFC62F2F),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(16.dp),
)

@Composable
fun CloneTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Light, shapes = AppShapes, content = content)

