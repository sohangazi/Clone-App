package com.example.clonespace

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

class AdminReceiver : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val dpm = context.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(context, AdminReceiver::class.java)
        dpm.setProfileName(admin, "Clones")
        dpm.setProfileEnabled(admin)
        val f = IntentFilter().apply {
            addAction(ProfileOpsActivity.ACTION_CLONE)
            addAction(ProfileOpsActivity.ACTION_LAUNCH)
            addAction(ProfileOpsActivity.ACTION_REMOVE)
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        dpm.addCrossProfileIntentFilter(admin, f, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED)
    }
}
